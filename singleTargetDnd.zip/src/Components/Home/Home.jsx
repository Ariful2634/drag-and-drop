import { useState } from "react";
import Circle from "../SidebarContent/Circle";
import Rectangle from "../SidebarContent/Rectangle";

const Home = () => {
  const [droppedItem, setDroppedItem] = useState(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  const handleDragStart = (e, item) => {
    e.dataTransfer.setData("application/react", JSON.stringify(item));
  };

  const handleDragEnd = () => {
    setIsDraggingOver(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragEnter = () => {
    setIsDraggingOver(true);
  };

  const handleDragLeave = () => {
    setIsDraggingOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();

    // If there's already a dropped item, prevent dropping again
    if (droppedItem) {
      alert("Already dropped an item. Cannot drop again.");
      return;
    }

    const draggedItem = JSON.parse(e.dataTransfer.getData("application/react"));
    const dropBox = document.getElementById("drop-box");
    const dropRect = dropBox.getBoundingClientRect();
    const x = e.clientX - dropRect.left;
    const y = e.clientY - dropRect.top;

    // Check if the drop occurred within the drop area
    if (x >= 0 && x <= dropRect.width && y >= 0 && y <= dropRect.height) {
      setDroppedItem(draggedItem);
    }
    setIsDraggingOver(false);
  };

  return (
    <div
      className="flex mx-auto"
      style={{ height: '100vh', width: '100vw' }}
    >
      <div
        className="w-64 min-h-screen bg-gray-200 flex justify-center"
        onDragOver={(e) => e.preventDefault()} // Prevent dragging onto the sidebar
      >
        <div className="space-y-3">
          <div className="w-full flex justify-center">
            <Circle
              onDragStart={(e) => handleDragStart(e, { type: "Circle" })}
              onDragEnd={handleDragEnd}
            />
          </div>
          <div>
            <Rectangle
              onDragStart={(e) => handleDragStart(e, { type: "Rectangle" })}
              onDragEnd={handleDragEnd}
            />
          </div>
        </div>
      </div>
      <div
        className="flex-1 p-6 ml-16"
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        style={{ position: 'relative' }} // Add position relative for the drop box
      >
        {/* Conditionally render the drop box border based on isDraggingOver and droppedItem */}
        <div
          id="drop-box"
          style={{
            width: 'fit-content', // Set width based on dropped item existence
            height: 'fit-content', // Set height based on dropped item existence
            border: (isDraggingOver && !droppedItem) ? '2px dashed black' : 'none', // Show border only when dragging over drop box and no item dropped
            position: 'absolute', // Position drop box absolutely
            top: '5%', // Center vertically
            left: '2%', // Center horizontally
            transform: 'translate(-20%, -20%)', // Center drop box
            padding: '40px',
          }}
        >
          {/* Render dropped item */}
          {droppedItem && droppedItem.type === "Circle" ? (
            <Circle />
          ) : droppedItem && droppedItem.type === "Rectangle" ? (
            <Rectangle />
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Home;
