import { useQuery } from "@tanstack/react-query";
import axios from "axios";


const ViewPage = () => {

    const {  data: getSource = [] } = useQuery({
        queryKey: ['getSource'],
        queryFn: async () => {
            const res = await axios.get('http://192.168.60.127:8085/get-source-info/');
            return res.data;
        }
    });

    console.log(getSource)

    return (
        <div>
            {
                getSource.map(source=>(<div key={source.position}>
                    <h2>Name: {source.source_name}</h2>
                    <p>Position: {source.position}</p>
                </div>))
            }
        </div>
    );
};

export default ViewPage;