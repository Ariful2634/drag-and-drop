/* eslint-disable react/prop-types */
import { useState } from "react";

const NamePopup = ({ onSubmit, onCancel }) => {
  const [name, setName] = useState("");
  const [type, setType] = useState("selectType");
  const [nameError, setNameError] = useState("");
  const [typeError, setTypeError] = useState("");

  const handleSubmit = () => {
    if (name.trim() === "") {
      setNameError("Name is required");
    } else {
      setNameError("");
    }

    if (type === "selectType") {
      setTypeError("Type is required");
    } else {
      setTypeError("");
    }

    if (name.trim() !== "" && type !== "selectType") {
      console.log("Name:", name.trim());
      console.log("Type:", type);
      onSubmit(name.trim(), type);
    } else {
      console.log("Please select a valid type.");
    }
  };

  return (
    <div className="fixed top-0 left-0 w-full h-full bg-gray-600 bg-opacity-50 flex justify-center items-center">
      <div className="bg-white p-8 rounded shadow">
        <p className="mb-2">Enter Type name:</p>
        <div className="flex items-center mb-4">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter Name here "
            className="border border-gray-400 px-3 py-1 rounded mr-2 flex-1"
          />
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="border border-gray-400 px-3 py-1 rounded"
          >
            <option value="selectType">Type</option>
            <option value="Source">Source</option>
            <option value="Load">Load</option>
          </select>
        </div>
        {nameError && <p className="text-red-500">{nameError}</p>}
        {typeError && <p className="text-red-500">{typeError}</p>}
        <div className="flex justify-end">
          <button className="bg-blue-500 text-white px-4 py-2 rounded mr-2" onClick={handleSubmit}>
            Submit
          </button>
          <button className="bg-gray-500 text-white px-4 py-2 rounded" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default NamePopup;