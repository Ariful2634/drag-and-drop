import { useState, useEffect } from "react";
import Circle from "../SidebarContent/Circle";
import NamePopup from "../SidebarContent/NamePopup";
import { Link } from "react-router-dom";

const Home = () => {
  const [droppedTopCircleItems, setDroppedTopCircleItems] = useState(Array(5).fill(null));
  const [hoveredTopCircleIndex, setHoveredTopCircleIndex] = useState([]);
  const [selectedTopCircleItem, setSelectedTopCircleItem] = useState(null);

  const [showPopup, setShowPopup] = useState(false); // State to control popup visibility
  const [popupIndex, setPopupIndex] = useState(null); // State to store the index of the circle associated with the popup

  useEffect(() => {
    const handleDragEndOutside = () => {
      setHoveredTopCircleIndex([]);
    };

    document.addEventListener("dragend", handleDragEndOutside);

    return () => {
      document.removeEventListener("dragend", handleDragEndOutside);
    };
  }, []);

  const handleDragStart = (e, item) => {
    e.dataTransfer.setData("application/react", JSON.stringify(item));
  };

  const handleDragEnd = () => {
    setHoveredTopCircleIndex([]);
  };

  const handleCircleDragOver = (e) => {
    e.preventDefault();
    const firstEmptyTopIndex = droppedTopCircleItems.findIndex((item) => item === null);
    let nextFilledTopIndex = -1;
    for (let i = droppedTopCircleItems.length - 1; i >= 0; i--) {
      if (droppedTopCircleItems[i] !== null) {
        nextFilledTopIndex = i + 1;
        break;
      }
    }
    setHoveredTopCircleIndex([firstEmptyTopIndex, nextFilledTopIndex]);
  };

  const handleDrop = (e, index) => {
    e.preventDefault();
    const draggedItem = JSON.parse(e.dataTransfer.getData("application/react"));
    if (draggedItem.type !== "Circle") {
      alert("Circle drop box can only contain circle items.");
      return;
    }
    setDroppedTopCircleItems((prevItems) => {
      const newItems = [...prevItems];
      newItems[index] = draggedItem;
      return newItems;
    });
    setHoveredTopCircleIndex([]);
    // Show the popup for this circle
    setShowPopup(true);
    setPopupIndex(index);
  };

  const handleDeleteTopCircle = () => {
    if (!selectedTopCircleItem) return;
    const index = droppedTopCircleItems.indexOf(selectedTopCircleItem);
    if (index !== -1) {
      const newItems = [...droppedTopCircleItems];
      newItems[index] = null;
      setDroppedTopCircleItems(newItems);
    }
    setSelectedTopCircleItem(null);
  };

  // Handler for submitting the name and type from the popup
  const handleSubmitPopup = (name, type) => {
    const index = popupIndex;
    if (index !== null) {
      setDroppedTopCircleItems((prevItems) => {
        const newItems = [...prevItems];
        newItems[index] = { ...newItems[index], name, type }; // Update the circle object with name and type
        return newItems;
      });
      setShowPopup(false);
      setPopupIndex(null);
    }
  };

  // Handler for canceling the name and type input
  const handleCancelPopup = () => {
    const index = popupIndex;
    if (index !== null) {
      setDroppedTopCircleItems((prevItems) => {
        const newItems = [...prevItems];
        newItems[index] = null; // Remove the dropped circle item
        return newItems;
      });
      setShowPopup(false);
      setPopupIndex(null);
    }
  };

  return (
    <div className="flex mx-auto" style={{ height: "100vh", width: "100vw" }}>
      {/* Sidebar content */}
      <div className="min-w-64 min-h-screen bg-gray-200 flex justify-center">
        <div className="space-y-3">
          <div className="w-full flex justify-center" onDragOver={handleCircleDragOver}>
            <Circle onDragStart={(e) => handleDragStart(e, { type: "Circle" })} onDragEnd={handleDragEnd} />
          </div>
          <div>
            <Link to='/viewPage'><button className="btn btn-accent">View Page</button></Link>
          </div>
        </div>
      </div>

      {/* Dropbox */}
      <div className="flex-1 pl-4 pt-4">
        <div style={{ position: "relative" }}>
          <div className="flex space-x-2">
            {droppedTopCircleItems.map((item, index) => (
              <div
                key={`top-circle-drop-${index}`}
                className="border border-dashed border-black"
                onDrop={(e) => handleDrop(e, index)}
                onDragOver={(e) => handleCircleDragOver(e)}
                style={{
                  width: "120px",
                  height: "120px",
                  borderRadius: "50%",
                  border: hoveredTopCircleIndex.includes(index) ? "2px dashed black" : "2px dashed transparent",
                }}
                onClick={() => setSelectedTopCircleItem(item)}
              >
                {item && <Circle name={item.name} />}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Popup for adding name and type */}
      {showPopup && (
        <NamePopup
          onSubmit={(name, type) => handleSubmitPopup(name, type)}
          onCancel={() => {
            setShowPopup(false);
            setPopupIndex(null);
            handleCancelPopup(); // Call the cancel handler
          }}
        />
      )}

      {/* Delete Popup for Top Circle */}
      {selectedTopCircleItem && (
        <div className="fixed top-0 left-0 w-full h-full bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-8 rounded shadow">
            <p>Are you sure you want to delete this top circle item?</p>
            <div className="flex justify-end mt-4">
              <button className="bg-red-500 text-white px-4 py-2 rounded mr-2" onClick={handleDeleteTopCircle}>
                Delete
              </button>
              <button className="bg-gray-500 text-white px-4 py-2 rounded" onClick={() => setSelectedTopCircleItem(null)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;