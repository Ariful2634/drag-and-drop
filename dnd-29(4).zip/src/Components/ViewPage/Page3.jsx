

const Page3 = () => {
    return (
        <div>
            <h2>Page 3</h2>
        </div>
    );
};

export default Page3;